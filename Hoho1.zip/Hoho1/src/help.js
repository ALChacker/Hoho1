const help = (prefix) => { 
	return `                 
┏━━━°❀ ❬ Hi ❭ ❀°━━━┓
┃❉ Hi. *${id.split("@s.whatsapp.net")[0]}* ❉
┃❉ Berikut Menu Dari *NewalBotツ* ❉
┏━━━°❀ ❬ 𝘼𝘽𝙊𝙐𝙏 ❭ ❀°━━━┓
┃
┏❉ *${prefix}owner*
┣❉ *${prefix}donasi*
┗❉ *${prefix}info*
┃
┣━━━°❀ ❬ 𝗠𝗔𝗞𝗘𝗥 ❭ ❀°━━━⊱
┃
┣➥ *${prefix}sticker*
┣➥ *${prefix}tsticker*
┣➥ *${prefix}nulis*
┃
┣━━━━°❀ ❬ 𝙈𝙀𝘿𝙄𝘼 ❭ ❀°━━━⊱
┃
┣➥ *${prefix}tts*
┣➥ *${prefix}tiktok*
┣➥ *${prefix}meme*
┣➥ *${prefix}memeindo*
┣➥ *${prefix}nsfwloli*
┣➥ *${prefix}ocr*
┣➥ *${prefix}loli*
┃
┣━━━°❀ ❬ 𝘿𝙊𝙒𝙉𝙇𝙊𝘼𝘿 ❭ ❀°━━⊱
┃
┣➥ *yt* [link]
┣➥ *play* [judul lagu]
┃
┣━━━━°❀ ❬ 𝙂𝙍𝙊𝙐𝙋 ❭ ❀°━━━━⊱
┃
┣➥ *${prefix}add* [62xxx]
┣➥ *${prefix}kick* [tag]
┣➥ *${prefix}setpp*
┣➥ *${prefix}demote* [tag]
┣➥ *${prefix}promote* [tag]
┣➥ *${prefix}setpp*
┣➥ *${prefix}group* [buka/tutup]
┣➥ *${prefix}welcome* [1/0]
┣➥ *${prefix}nsfw* [1/0]
┣➥ *${prefix}simih* [1/0]
┃
┣━━━━━°❀ ❬ 𝙊𝙒𝙉𝙀𝙍 ❭ ❀°━━━━⊱
┃
┣➥ *${prefix}bc* 
┣➥ *${prefix}leave*
┣➥ *${prefix}clearall*
┣➥ *${prefix}setprefix*
┣➥ *${prefix}clone* [tag]
┣➥ *${prefix}block*
┣➥ *${prefix}unblock*
┃
┣━━━━°❀ ❬ 𝙊𝙏𝙃𝙀𝙍 ❭ ❀°━━━━━⊱
┃
┣➥ *${prefix}ytsearch*
┣➥ *${prefix}listadmin*
┣➥ *${prefix}blocklist*
┣➥ *${prefix}simi*
┣➥ *${prefix}wait*
┣➥ *${prefix}fitnah*
┣➥ *${prefix}tiktokstalk*
┣➥ *${prefix}url2img*
┃
┣━━━━━━━━━━━━━━━━━━━━
┃ 
┗━━━━━━━━━━━━━━━━━━━━`
}
exports.help = help



  
